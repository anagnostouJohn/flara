#
#
# class Dog():
#     abc = 10
#     def __init__(self, length_old):
#         self.length=length_old
#         self.size = 10
#
#     @staticmethod # Ειναι μια κλασίκή def που ορίζεται μέσα σε μία κλάση! Δεω χριάζεται να βάλουμε το self
#                     # ωστε να πέρνει όλα τα ορίσματα της κλάσης. ΔΕΝ μπορώ να χρησιμοποιήσω τα ορίσματα της κλάσης
#     def calculate_size(self, size):
#         #print(length)
#         #print(length_old)
#         #print(self.length_old)
#         #print(self.length)
#         size += 10
#         print(size)
#
#     @classmethod #ΑΝ ΔΕΝ χρησιμοποιηθούν υποκλάσεις χρησιμοποιείται ως μια staticmethod ΔΕΝ θα ζητηθει διοτι δεν θα ζχρησιμοποιησρεται υποκλάσςεις
#     def calculate_other_size(cls,a):
#         print(cls.calculate_size(33,11))
#
#
# p = Dog(3)
# #p.calculate_size(1,7)
# p.calculate_other_size(33)

####################IP######################333
# szukane = r'(?:\d{1,3}\.)+(?:\d{1,3})'
# chunk = "wefwef192.1f68.320.165f3f3 gv ger retb  ege e ge  erg e101.0.1.10erg erg erg g re"
# # ip_v4 = r".*\b(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\b.*"
# # regex = re.compile(ip_v4)
# regex1 = re.compile(szukane)
#
# # url = re.match(regex, chunk)
# url2 = re.findall(regex1, chunk)
# #print(url)
# print(url2)
####################IP######################333
# regex = re.compile(
#     r'^(?:http|ftp)s?://'  # http:// or https://
#     r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+(?:[A-Z]{2,6}\.?|[A-Z0-9-]{2,}\.?)|'  # domain...
#     r'localhost|'  # localhost...
#     r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'  # ...or ip
#     r'(?::\d+)?'  # optional port
#     r'(?:/?|[/?]\S+)$', re.IGNORECASE)
#
# paths  = r"(\\\\?([^\\/]*[\\/])*)([^\\/]+)$"
# paths2 = r"(\/.*?\.[\w:]+)"
# chunk = "c:/"
# regex = re.compile(paths2)
# res = re.findall(regex, chunk)
#
# z = '(\/.*?\.[\w:]+)'
#
# f = r"[a-zA-Z]:\\((?:[a-zA-Z0-9() ]*\\)*).*"
#
# w =r"((?:(?:[a-zA-Z]:)|//home)[^\.]+\.[A-Za-z]{3})"
#
# o = r"(\\\\?([^\\/]*[\\/])*)([^\\/]+)"
#
# p = r"/^\/abcd\/[^\/]+$/"
# number_range = r"(0|[1-9][0-9]{0,3}|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-5]){0-1}"
# #site_path = r"www\.[a-z]*[\.]*"
# #(http|https|ftp|ftps)?[\:]?[\\|/]?
#
#
#
# ipv4 =  r'(?:\d{1,3}\.)+(?:\d{1,3})'   # OK
# win_path = r"[a-z][\:][\\|/][a-z]*[0-9]*[\\|/]*[a-z]*[0-9]*[\\|/]*[a-z]*[0-9]*"
# site_path = r"[w]{0,3}[\.]{0,1}.[^ ]*\.[a-z0-9]{2,6}[\\|/]*.[^ ]*[\\|/]*.[^ ]*[\\|/]*.[^ ]*[\\|/]*.[^ ]*[\\|/]*"
# http_https = r"(?:http|ftp)s?://.*"
# base_64 = r"(?:[A-Za-z0-9+/]{4}){2,}(?:[A-Za-z0-9+/]{2}[AEIMQUYcgkosw048]=|[A-Za-z0-9+/][AQgw]==)"
# hex_blob = r'([A-F]{10}|[0-9]{10})'
# email = r"[A-Z0-9._%+-]+@(?:[A-Z0-9-]+\.)+(?:[A-Z]{2,12}|XN--[A-Z0-9]{4,18})"
# pat_win32= r"WriteFile|IsDebuggerPresent|RegSetValue|CreateRemoteThread"
# pat_winsock = r"WS2_32.dll|WSASocket|WSASend|WSARecv|Microsoft Visual C++"
# pat_regkeys = r"HKEY_LOCAL_MACHINE|HKEY_CURRENT_USER|CurrentVersion.Run|CurrentVersion.RunOnce|UserInit"
# filenames =r"\\drivers\\etc\\hosts|cmd\.exe|\\Start Menu\\Programs\\Startup"
# intresting_strs = r"password|login|pwd|administrator|admin|root|smtp|pop|ftp|ssh|icq|backdoor|vmware"
# words_3 = r"([A-Za-z0-9]{2,}\s){2,}[A-Za-z0-9]{2,}"
# more_than_six_chars = r"\b(?:[A-Z]{6,}|[A-Za-z][a-z]{5,})\b"
# strings_only = r"[a-z0-9]{3,}"
# links = r'(?:ftp|hxxp)[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
# chars = r"A-Za-z0-9/\-:.,_$%@'()\\\{\};\]\[<> "
# regexp = r'[%s]{%d,100}' % (chars, 6)
# print(regexp)
# #http_https = r"^(http|https|ftp|ftps)[\:][\\|//].*\.[a-z0-9]{2,6}"
#
#
#
#
# #x = re.findall(win_path, "vevergwbvrbetbwrbrve wefrggrsvd:/john/12fes_kt214obbqtrep/1234 rebwv erv rbtwwr/gwgFwfwE:/windows/temp file c:/132ψ εdwe path /log/file.txt some lergerg ergergines /log/var/file2.txt wefwe fwef wef  eberbeb", re.IGNORECASE)
# #x = re.match(site_path, r"cewcwcwww.hello.com")
# #x = re.findall(site_path, r"cewcwc t45www.hel//l-1235-o.com:4345/fwefwefwef/rr  hey www.there.com")
# #x = re.findall(regexp, r"cewcwc trgefvdscftp://.hel//l-1235-o.co134:1234/fwefwefwef;oulnj.km https://.there.comfqergrergergeergg http:\\.there.com grtgrtgrt\rgtgrtg\rgtgrtgr")
# #x = re.findall(hex_blob, r"aaaaA1A1111AAAFFFAAFAFAFAFfA1AAAA1AAAAA11111111111111111111AAAAaa1aaa1aaa",re.IGNORECASE)
# #x = re.findall(email, r"aaaaA1A1111AAAFFFAAFAFAFAFfAhello@yahoo.com1AAAA1AAAAA11111111111111111111AAAAaa1aaa1aaa",re.IGNORECASE)
# #x = re.findall(pat_win32, r"aaaaA1A1111AAAFFFAAFAFAFAFfAhello@yahoo.com1AAWriteFileAA1AAAARegSetValueA11111111111111IsDebuggerPresent111111AAAAaa1aaa1aaa",re.IGNORECASE)
# #x = re.findall(pat_regkeys, r"aaaaA1A1HKEY_LOCAL_MACHINE111AAAFFFAAFAFAFAFfAhello@yahoo.com1AAWriteFileAACurrentVersion\RunOnce1AAAARegSetValueA11111111111111IsDebuggerPresent111111AAAAaa1aaa1HKEY_CURRENT_USERaaa",re.IGNORECASE)
# #x = re.findall(filenames, r"aaaaA1A1HKEY_LOCAL_MACHINE111AAcmd.exeAFFFAAFAFAFA\drivers\etc\hostsFfAhello@yahoo.com1AAWriteFileAACurrentVersion\RunOnce1AAA\Start Menu\Programs\StartupARegSetValueA11111111111111IsDebuggerPresent111111AAAAaa1aaa1HKEY_CURRENT_USERaaa",re.IGNORECASE)
# #x = re.findall(words_3, r"aaaaA1A1 HKEY_L OCAL_ MACHINE111AAcmd.exeAFF FA AFAFA FA\drivers\etc\hostsFfAhello@yahoo.com1AAWr iteFil eAACurrentVer sion \RunOnce1AAA\Start Menu\Programs\StartupARegSetValueA11111111111111IsDebuggerPresent111111AAAAaa1aaa1HKEY_CURRENT_USERaaa",re.IGNORECASE)
# #x = re.findall(links, r"aaaaA1A1 HKEY_L OCAL_ MACHINE111AAcmd.exeAFF FA AFAFA FA\drivers\etc\hostsFfAhello@yahoo.com1AAWr iteFil eAACurrentVer sion \RunOnce1AAA\Start Menu\Programs\StartupARegSet\ValueA11111111111111IsDebuggerPresent111111AAA Aaa1aaa1HKEY_CURRENT_USERaaa",re.IGNORECASE)
# #x = re.findall(chars, r"DB9//6r73*Np}et#s*X<U7&d]3|{K(uYLy%(s(um2_u:'k9jU=1xcWJF~oa-E&-2iW)rD@{t|@:>7	U9[{><UL>{`h0qH]PETgnf7tk",re.IGNORECASE)
# x = re.findall(regexp, "qrg\hfdc tg eh rte hrth r")
#
# # print(x)
# #
# # print(len(x[0]))
# #
# # print(len("aa"))
# #
#
# L= ["a","b","c"]
# str1 = " ".join(L)
# print(str1)

#
# import  ron
# path = r"C:\Users\john\Desktop\2.txt"
# x = ron.create_new_yara(path)
# print("ccccc",x.ret_all_str())
#
# file = open(r"C:\Users\john\Desktop\workSpace\yara_cr\Yara_1.yara","r")
# x = file.read()
# print(x)

# x = "5B706C61796C6973745D"
# y = "5B70"
# z = "25504446"
# def mb(mb):
#     if len(mb) >=8:
#         x = mb[0:8]
#         of = "32"
#         res = "".join(map(str.__add__, mb[-2::-2], mb[-1::-2]))
#     elif len(mb)>=4 and len(mb)<8:
#         x=mb[0:4]
#         of = "16"
#         res = "".join(map(str.__add__, mb[-2::-2], mb[-1::-2]))
#     elif len(mb)>=2 and len(mb)<4:
#         x=mb[0:2]
#         of = "8"
#         res = "".join(map(str.__add__, mb[-2::-2], mb[-1::-2]))
#     else:
#         print("HELLO")
#         of=""
#         res = ""
#     return of, res
#
# print(mb(x))
# print(mb(y))
# print(mb(z))

# hexnum = 0xffffabcd
# print(type(bytes(hexnum)))
# z = hexnum.to_bytes(4, 'little')
# print(z)
# import math
# import os
# x = int(os.path.getsize(r'C:\Users\john\Desktop\1.pdf'))
#
# print(x)
# print(int(x/1024))
# x = math.floor(1.99999999)
# print(x)

# L =  ["a","b"]
# if "g" in L:
#     print("OK")
# import random
# L = [1,2,3,4,5,6,7,8,9,10]
# for i in range(10):
#     x = random.sample(L)0
# import os
# print(int(os.path.getsize(r"C:\Users\john\Desktop\1.pdf")))
# import string
# import sqlite3
# #
# # def strings(filename, min=4):
# #     with open(filename, errors="ignore") as f:  # Python 3.x
# #     # with open(filename, "rb") as f:           # Python 2.x
# #         result = ""
# #         for c in f.read():
# #             if c in string.printable:
# #                 result += c
# #                 continue
# #             if len(result) >= min:
# #                 print(result)
# #             result = ""
# #         if len(result) >= min:  # catch result at EOF
# #             print(result)
# # strings(r"C:\Users\john\Desktop\1.pdf")
# #
# # x = "endstream"
# #
# # print("__________________________________________")
# # print(x.encode("hex"))
# # print(hex(x))
# import re
# import pefile
# def extract_opcodes(fileData):
#     # String list
#     opcodes = []
#
#     # Read file data
#     try:
#         print("in")
#         pe = pefile.PE(data=fileData)
#
#         name = ""
#
#         ep = pe.OPTIONAL_HEADER.AddressOfEntryPoint
#         pos = 0
#         for sec in pe.sections:
#             print("in1")
#             if (ep >= sec.VirtualAddress) and \
#                     (ep < (sec.VirtualAddress + sec.Misc_VirtualSize)):
#                 print("in3")
#                 name = sec.Name.replace(b'\x00', b'')
#
#                 break
#             else:
#                 pos += 1
#
#         for section in pe.sections:
#             # print("in2")
#             # print(section)
#             # text = section.get_data()
#             # print(text)
#             # text_parts = re.split("[\x00]{3,}".encode(), text)
#             # print(text_parts)
#             if section.Name.rstrip("\x00".encode()) == name:
#                 print("in4")
#                 text = section.get_data()
#                 # Split text into subs
#                 print("in5")
#                 text_parts = re.split("[\x00]{3,}".encode(), text)
#                 print("in6")
#                 # Now truncate and encode opcodes
#                 for text_part in text_parts:
#                     if text_part == '' or len(text_part) < 8:
#                         continue
#                     print(text_part[:16])
#                     #opcodes.append(text_part[:16].encode('hex'))
#                     opcodes.append(text_part[:16].hex())
#         print(opcodes)
#
#     except Exception as e:
#         #if args.debug:
#         #    traceback.print_exc()
#         print(e)
#         pass
#
# f = open("WdfCoInstaller01009.dll","rb")
# x = f.read()
# extract_opcodes(x)
# #
# # x= "abcd><!@#$^&*()(*&^ %$#@\\"
# # z = " !@#$%^&*()-+{}\",.<>?/;'\\[]:"
# # for i in z:
# #     x = x.replace(i,"")
# # print(x)
# #
# # #
# #
# # x = b'V\xe8\x90\x83\x00\x00\x8b\xf0\xe8\x83\x83\x00\x00\xff6\xff'
# #
# # print(x.hex())

# import zipfile
# p = r"C:\Users\john\Desktop\workSpace\yara_cr\app.exe"
# p = r"C:\Users\john\Desktop\workSpace\yara_cr\app.exe"
# zip = r"C:\Users\john\Desktop\workSpace\yara_cr\z.zip"
# my_zip = zipfile.ZipFile(zip, "w", zipfile.ZIP_DEFLATED)
# #my_zip.write("info.txt")
# my_zip.write("C:/Users/john/Desktop/workSpace/yara_cr/app.exe","app.exe")
# my_zip.close()

for i in range(10,-1,-1):
    print(i)